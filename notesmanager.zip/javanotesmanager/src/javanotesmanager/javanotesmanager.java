package javanotesmanager;
import java.io.*;
import java.util.Scanner;

public class javanotesmanager {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            
            FileWriter writer1 = new FileWriter("JavaFile1.txt");
            System.out.println("Enter the content for JavaFile1.txt:");
            String[] lines1 = {
                "Java is an object-oriented programming language.",
                "It supports encapsulation, inheritance, and polymorphism.",
                "File handling in Java allows for efficient reading and searching of text.",
                "Keep learning and mastering Java!"
            };
            for (String line : lines1) {
                writer1.write(line + "\n");
            }
            writer1.close();
            System.out.println("JavaFile1.txt created successfully.\n");

            System.out.println("Content of JavaFile1.txt:");
            BufferedReader reader1 = new BufferedReader(new FileReader("JavaFile1.txt"));
            String line;
            while ((line = reader1.readLine()) != null) {
                System.out.println(line);
            }
            reader1.close();
            System.out.println();
            FileWriter writer2 = new FileWriter("JavaFile2.txt");
            writer2.write("This is the first line in this JavaFile2.txt file.\n");
            writer2.close();
            System.out.println("JavaFile2.txt created with initial line.\n");
            FileOutputStream fos = new FileOutputStream("JavaFile2.txt", true); // append = true
            FileInputStream fis = new FileInputStream("JavaFile1.txt");

            int content;
            while ((content = fis.read()) != -1) {
                fos.write(content);
            }

            fis.close();
            fos.close();
            System.out.println("Content from JavaFile1.txt copied to JavaFile2.txt.\n");
            BufferedReader analyzeReader = new BufferedReader(new FileReader("JavaFile1.txt"));

            int charCount = 0;
            int wordCount = 0;
            int lineCount = 0;
            int polyCount = 0;
            int lineNumber = 0;
            String searchWord = "polymorphism";

            System.out.println("Analyzing JavaFile1.txt...\n");

            String currentLine;
            while ((currentLine = analyzeReader.readLine()) != null) {
                lineNumber++;
                lineCount++;
                charCount += currentLine.length();
                String[] words = currentLine.split("\\s+");
                wordCount += words.length;

                if (currentLine.contains(searchWord)) {
                    System.out.println("The word \"" + searchWord + "\" found at line: " + lineNumber);
                    for (String word : words) {
                        if (word.replaceAll("\\p{Punct}", "").equalsIgnoreCase(searchWord)) {
                            polyCount++;
                        }
                    }
                }
            }

            System.out.println("\nTotal characters: " + charCount);
            System.out.println("Total lines: " + lineCount);
            System.out.println("Total words: " + wordCount);
            System.out.println("Total occurrences of \"" + searchWord + "\": " + polyCount);

            analyzeReader.close();

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    } 
}
